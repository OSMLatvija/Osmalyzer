echo "DICT lv LV lv_LV" >>dictionary.lst
echo "HYPH lv LV hyph_lv_LV" >>dictionary.lst